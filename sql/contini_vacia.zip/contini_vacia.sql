/*
SQLyog Ultimate v8.61 
MySQL - 5.7.26-0ubuntu0.18.04.1 : Database - contini
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `afip_alicuota` */

CREATE TABLE `afip_alicuota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_desde` datetime NOT NULL,
  `fecha_hasta` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_A4F7CB0720332D99` (`codigo`),
  KEY `IDX_A4F7CB07DE12AB56` (`created_by`),
  KEY `IDX_A4F7CB0716FE72E1` (`updated_by`),
  CONSTRAINT `FK_A4F7CB0716FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_A4F7CB07DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `afip_alicuota` */

insert  into `afip_alicuota`(`id`,`codigo`,`descripcion`,`fecha_desde`,`fecha_hasta`,`created_by`,`created_at`,`updated_by`,`updated_at`,`activo`) values (1,1,'No Gravado','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0),(2,2,'Exento','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0),(3,3,'0','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0),(4,9,'2.5','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0),(5,8,'5','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0),(6,4,'10.50','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',1),(7,5,'21.00','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',1),(8,6,'27','2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30',0);

/*Table structure for table `afip_comprobante_tipo` */

CREATE TABLE `afip_comprobante_tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_desde` datetime NOT NULL,
  `fecha_hasta` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `compra` tinyint(1) NOT NULL,
  `venta` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9A0C5DDADE12AB56` (`created_by`),
  KEY `IDX_9A0C5DDA16FE72E1` (`updated_by`),
  CONSTRAINT `FK_9A0C5DDA16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_9A0C5DDADE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `afip_comprobante_tipo` */

insert  into `afip_comprobante_tipo`(`id`,`codigo`,`descripcion`,`fecha_desde`,`fecha_hasta`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`,`compra`,`venta`) values (1,1,'FACTURA A','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(2,2,'NOTAS DE DEBITO A','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(3,3,'NOTAS DE CREDITO A','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(4,4,'RECIBOS A','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(5,5,'NOTAS DE VENTA AL CONTADO A','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(6,6,'FACTURA B','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(7,7,'NOTAS DE DEBITO B','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(8,8,'NOTAS DE CREDITO B','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,1),(9,9,'RECIBOS B','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(10,10,'NOTAS DE VENTA AL CONTADO B','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(11,11,'FACTURA C','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,0),(12,12,'NOTAS DE DEBITO C','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,0),(13,13,'NOTAS DE CREDITO C','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',1,0),(15,15,'RECIBOS C','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(16,16,'NOTAS DE VENTA AL CONTADO C','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00',0,0),(17,0,'REMITO','2009-02-20 00:00:00','2099-02-20 00:00:00',1,1,'2019-05-28 17:21:08',1,'2019-05-28 17:21:08',1,1);

/*Table structure for table `afip_condicion_venta` */

CREATE TABLE `afip_condicion_venta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_desde` datetime NOT NULL,
  `fecha_hasta` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_5FB4E34120332D99` (`codigo`),
  KEY `IDX_5FB4E341DE12AB56` (`created_by`),
  KEY `IDX_5FB4E34116FE72E1` (`updated_by`),
  CONSTRAINT `FK_5FB4E34116FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_5FB4E341DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `afip_condicion_venta` */

insert  into `afip_condicion_venta`(`id`,`codigo`,`descripcion`,`fecha_desde`,`fecha_hasta`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,1,'Contado','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(2,2,'Tarjeta Debito','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(3,3,'Tarjeta Credito','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(4,4,'Cuenta Corriente','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(5,5,'Cheque','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(6,6,'Ticket','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00'),(7,7,'Otra','2009-02-20 00:00:00','2030-02-20 00:00:00',1,1,'2019-01-06 00:00:00',1,'2019-01-06 00:00:00');

/*Table structure for table `afip_documento_tipo` */

CREATE TABLE `afip_documento_tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `fecha_desde` datetime NOT NULL,
  `fecha_hasta` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_99D85FF20332D99` (`codigo`),
  KEY `IDX_99D85FFDE12AB56` (`created_by`),
  KEY `IDX_99D85FF16FE72E1` (`updated_by`),
  CONSTRAINT `FK_99D85FF16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_99D85FFDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `afip_documento_tipo` */

insert  into `afip_documento_tipo`(`id`,`codigo`,`descripcion`,`activo`,`fecha_desde`,`fecha_hasta`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,80,'CUIT',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30'),(2,87,'CDI',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30'),(3,91,'CI Extranjera',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30'),(4,94,'Pasaporte',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30'),(5,96,'DNI',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30'),(6,99,'Otro',1,'2009-02-20 00:00:00',NULL,1,'2018-12-27 13:31:30',1,'2018-12-27 13:31:30');

/*Table structure for table `afip_iva_condicion` */

CREATE TABLE `afip_iva_condicion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_25EFE430DE12AB56` (`created_by`),
  KEY `IDX_25EFE43016FE72E1` (`updated_by`),
  CONSTRAINT `FK_25EFE43016FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_25EFE430DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `afip_iva_condicion` */

insert  into `afip_iva_condicion`(`id`,`codigo`,`descripcion`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,1,'IVA Responsable Inscripto',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(2,2,'IVA Responsable no Inscripto',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(3,3,'IVA no Responsable',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(4,4,'IVA Sujeto Exento',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(5,5,'Consumidor Final',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(6,6,'Responsable Monotributo',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(7,7,'Sujeto no Categorizado',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(8,8,'Proveedor del Exterior',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(9,9,'Cliente del Exterior',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00');

/*Table structure for table `articulo` */

CREATE TABLE `articulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio_costo` decimal(16,2) NOT NULL,
  `ganancia_porcentaje` decimal(16,2) NOT NULL,
  `precio_venta` decimal(16,2) NOT NULL,
  `cantidad` decimal(16,2) NOT NULL,
  `cantidad_minima` decimal(16,2) NOT NULL,
  `precio_modifica` tinyint(1) NOT NULL,
  `genero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `material` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forma` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estilo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_marco` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color_cristal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `orden_trabajo` tinyint(1) NOT NULL,
  `afip_alicuota_id` int(11) DEFAULT NULL,
  `ultimo_comprobante_id` int(11) DEFAULT NULL,
  `precio_venta_sin_iva` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_69E94E913397707A` (`categoria_id`),
  KEY `IDX_69E94E9181EF0041` (`marca_id`),
  KEY `IDX_69E94E9168D9BA2B` (`afip_alicuota_id`),
  KEY `IDX_69E94E916E8AE207` (`ultimo_comprobante_id`),
  KEY `IDX_69E94E91DE12AB56` (`created_by`),
  KEY `IDX_69E94E9116FE72E1` (`updated_by`),
  CONSTRAINT `FK_69E94E9116FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_69E94E913397707A` FOREIGN KEY (`categoria_id`) REFERENCES `articulo_categoria` (`id`),
  CONSTRAINT `FK_69E94E9168D9BA2B` FOREIGN KEY (`afip_alicuota_id`) REFERENCES `afip_alicuota` (`id`),
  CONSTRAINT `FK_69E94E916E8AE207` FOREIGN KEY (`ultimo_comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_69E94E9181EF0041` FOREIGN KEY (`marca_id`) REFERENCES `articulo_marca` (`id`),
  CONSTRAINT `FK_69E94E91DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `articulo` */

/*Table structure for table `articulo_categoria` */

CREATE TABLE `articulo_categoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B904BF0EDE12AB56` (`created_by`),
  KEY `IDX_B904BF0E16FE72E1` (`updated_by`),
  CONSTRAINT `FK_B904BF0E16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_B904BF0EDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `articulo_categoria` */

insert  into `articulo_categoria`(`id`,`descripcion`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Sin Especificar',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00');

/*Table structure for table `articulo_marca` */

CREATE TABLE `articulo_marca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_50BA305CDE12AB56` (`created_by`),
  KEY `IDX_50BA305C16FE72E1` (`updated_by`),
  CONSTRAINT `FK_50BA305C16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_50BA305CDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `articulo_marca` */

insert  into `articulo_marca`(`id`,`descripcion`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Sin Especificar',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00');

/*Table structure for table `cliente` */

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `documento_numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `localidad_id` int(11) DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `iva_condicion_id` int(11) DEFAULT NULL,
  `documento_tipo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F41C9B252DCBF3BC` (`documento_numero`),
  KEY `IDX_F41C9B2542D4BDD0` (`iva_condicion_id`),
  KEY `IDX_F41C9B2567707C89` (`localidad_id`),
  KEY `IDX_F41C9B257C9FBE9A` (`documento_tipo_id`),
  KEY `IDX_F41C9B25DE12AB56` (`created_by`),
  KEY `IDX_F41C9B2516FE72E1` (`updated_by`),
  CONSTRAINT `FK_F41C9B2516FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_F41C9B2542D4BDD0` FOREIGN KEY (`iva_condicion_id`) REFERENCES `afip_iva_condicion` (`id`),
  CONSTRAINT `FK_F41C9B2567707C89` FOREIGN KEY (`localidad_id`) REFERENCES `localidad` (`id`),
  CONSTRAINT `FK_F41C9B257C9FBE9A` FOREIGN KEY (`documento_tipo_id`) REFERENCES `afip_documento_tipo` (`id`),
  CONSTRAINT `FK_F41C9B25DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `cliente` */

/*Table structure for table `cliente_pago` */

CREATE TABLE `cliente_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recibo_id` int(11) DEFAULT NULL,
  `pago_tipo_id` int(11) DEFAULT NULL,
  `importe` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AF7697592C458692` (`recibo_id`),
  KEY `IDX_AF769759C6690F67` (`pago_tipo_id`),
  KEY `IDX_AF769759DE12AB56` (`created_by`),
  KEY `IDX_AF76975916FE72E1` (`updated_by`),
  CONSTRAINT `FK_AF76975916FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_AF7697592C458692` FOREIGN KEY (`recibo_id`) REFERENCES `recibo` (`id`),
  CONSTRAINT `FK_AF769759C6690F67` FOREIGN KEY (`pago_tipo_id`) REFERENCES `pago_tipo` (`id`),
  CONSTRAINT `FK_AF769759DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `cliente_pago` */

/*Table structure for table `comprobante` */

CREATE TABLE `comprobante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `punto_venta` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `total_bonificacion` decimal(16,2) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `total_no_gravado` decimal(16,2) NOT NULL,
  `total_neto` decimal(16,2) NOT NULL,
  `importe_iva_exento` decimal(16,2) NOT NULL,
  `importe_iva` decimal(16,2) NOT NULL,
  `importe_tributos` decimal(16,2) NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `obra_social_id` int(11) DEFAULT NULL,
  `obra_social_plan_id` int(11) DEFAULT NULL,
  `total_costo` decimal(16,2) NOT NULL,
  `total_ganancia` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `movimiento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cae_fecha_vencimiento` datetime DEFAULT NULL,
  `cae_numero` bigint(20) DEFAULT NULL,
  `afip_numero` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `condicion_venta_id` int(11) DEFAULT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `ordentrabajo_id` int(11) DEFAULT NULL,
  `saldo` decimal(16,2) NOT NULL,
  `pendiente` decimal(16,2) NOT NULL,
  `ordentrabajocontactologia_id` int(11) DEFAULT NULL,
  `cliente_razon_social` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cliente_documento_tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cliente_documento_numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cliente_domicilio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cliente_localidad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cliente_iva_condicion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_55DEEE82CB305D73` (`proveedor_id`),
  KEY `IDX_55DEEE82DE734E51` (`cliente_id`),
  KEY `IDX_55DEEE82A9276E6C` (`tipo_id`),
  KEY `IDX_55DEEE821C97F2C6` (`condicion_venta_id`),
  KEY `IDX_55DEEE82279A5D5E` (`sucursal_id`),
  KEY `IDX_55DEEE826D8BE9D2` (`obra_social_id`),
  KEY `IDX_55DEEE825BEDAD82` (`obra_social_plan_id`),
  KEY `IDX_55DEEE827D8D9FA3` (`ordentrabajo_id`),
  KEY `IDX_55DEEE82BBD33588` (`ordentrabajocontactologia_id`),
  KEY `IDX_55DEEE82DE12AB56` (`created_by`),
  KEY `IDX_55DEEE8216FE72E1` (`updated_by`),
  CONSTRAINT `FK_55DEEE8216FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_55DEEE821C97F2C6` FOREIGN KEY (`condicion_venta_id`) REFERENCES `afip_condicion_venta` (`id`),
  CONSTRAINT `FK_55DEEE82279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_55DEEE825BEDAD82` FOREIGN KEY (`obra_social_plan_id`) REFERENCES `obra_social_plan` (`id`),
  CONSTRAINT `FK_55DEEE826D8BE9D2` FOREIGN KEY (`obra_social_id`) REFERENCES `obra_social` (`id`),
  CONSTRAINT `FK_55DEEE827D8D9FA3` FOREIGN KEY (`ordentrabajo_id`) REFERENCES `orden_trabajo` (`id`),
  CONSTRAINT `FK_55DEEE82A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `afip_comprobante_tipo` (`id`),
  CONSTRAINT `FK_55DEEE82BBD33588` FOREIGN KEY (`ordentrabajocontactologia_id`) REFERENCES `orden_trabajo_contactologia` (`id`),
  CONSTRAINT `FK_55DEEE82CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_55DEEE82DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_55DEEE82DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `comprobante` */

/*Table structure for table `comprobante_detalle` */

CREATE TABLE `comprobante_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comprobante_id` int(11) DEFAULT NULL,
  `articulo_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `total_no_gravado` decimal(16,2) NOT NULL,
  `total_neto` decimal(16,2) NOT NULL,
  `importe_iva_exento` decimal(16,2) NOT NULL,
  `importe_iva` decimal(16,2) NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `precio_costo` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `precio_venta` decimal(16,2) NOT NULL,
  `importe_ganancia` decimal(16,2) NOT NULL,
  `precio_unitario` decimal(16,2) NOT NULL,
  `movimiento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje_bonificacion` decimal(16,2) NOT NULL,
  `importe_bonificacion` decimal(16,2) NOT NULL,
  `porcentaje_iva` decimal(16,2) NOT NULL,
  `porcentaje_ganancia` decimal(16,2) NOT NULL,
  `precio_neto` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6E37FF4425662B3A` (`comprobante_id`),
  KEY `IDX_6E37FF442DBC2FC9` (`articulo_id`),
  KEY `IDX_6E37FF44DE12AB56` (`created_by`),
  KEY `IDX_6E37FF4416FE72E1` (`updated_by`),
  CONSTRAINT `FK_6E37FF4416FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_6E37FF4425662B3A` FOREIGN KEY (`comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_6E37FF442DBC2FC9` FOREIGN KEY (`articulo_id`) REFERENCES `articulo` (`id`),
  CONSTRAINT `FK_6E37FF44DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `comprobante_detalle` */

/*Table structure for table `funcion` */

CREATE TABLE `funcion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `funcion` */

insert  into `funcion`(`id`,`modulo`,`accion`,`descripcion`) values (1,'Usuarios','Index','Usuarios - Listar'),(2,'Usuarios','Show','Usuarios - Mostrar'),(3,'Usuarios','New','Usuarios - Nuevo'),(4,'Usuarios','Edit','Usuarios - Editar'),(5,'Usuarios','Delete','Usuarios - Borrar'),(6,'Cliente','Index','Clientes - Listar'),(7,'Cliente','Show','Clientes - Mostrar'),(8,'Cliente','New','Clientes - Nuevo'),(9,'Cliente','Edit','Clientes - Editar'),(10,'Cliente','Delete','Clientes - Borrar'),(11,'Sucursal','Index','Sucursal - Listar'),(12,'Sucursal','Show','Sucursal - Mostrar'),(13,'Sucursal','New','Sucursal - Nuevo'),(14,'Sucursal','Edit','Sucursal - Editar'),(15,'Sucursal','Delete','Sucursal - Borrar'),(16,'Rol','Index','Rol - Listar'),(17,'Rol','Show','Rol - Mostrar'),(18,'Rol','New','Rol - Nuevo'),(19,'Rol','Edit','Rol - Editar'),(20,'Rol','Delete','Rol - Borrar'),(21,'Recibo','Index','Recibo - Listar'),(22,'Recibo','Show','Recibo - Mostrar'),(23,'Recibo','New','Recibo - Nuevo'),(24,'Recibo','Edit','Recibo - Editar'),(25,'Recibo','Delete','Recibo - Borrar'),(26,'ReciboComprobante','Index','Recibo Comprobante - Listar'),(27,'ReciboComprobante','Show','Recibo Comprobante - Mostrar'),(28,'ReciboComprobante','New','Recibo Comprobante - Nuevo'),(29,'ReciboComprobante','Edit','Recibo Comprobante - Editar'),(30,'ReciboComprobante','Delete','Recibo Comprobante - Borrar'),(31,'Proveedor','Index','Proveedor - Listar'),(32,'Proveedor','Show','Proveedor - Mostrar'),(33,'Proveedor','New','Proveedor - Nuevo'),(34,'Proveedor','Edit','Proveedor - Editar'),(35,'Proveedor','Delete','Proveedor - Borrar'),(36,'PagoTipo','Index','Tipo de Pago - Listar'),(37,'PagoTipo','Show','Tipo de Pago - Mostrar'),(38,'PagoTipo','New','Tipo de Pago - Nuevo'),(39,'PagoTipo','Edit','Tipo de Pago - Editar'),(40,'PagoTipo','Delete','Tipo de Pago - Borrar'),(41,'OrdenTrabajoDetalle','Index','OrdenTrabajo Detalle - Listar'),(42,'OrdenTrabajoDetalle','Show','OrdenTrabajo Detalle - Mostrar'),(43,'OrdenTrabajoDetalle','New','OrdenTrabajo Detalle - Nuevo'),(44,'OrdenTrabajoDetalle','Edit','OrdenTrabajo Detalle - Editar'),(45,'OrdenTrabajoDetalle','Delete','OrdenTrabajo Detalle - Borrar'),(46,'OrdenTrabajo','Index','Orden Trabajo - Listar'),(47,'OrdenTrabajo','Show','Orden Trabajo - Mostrar'),(48,'OrdenTrabajo','New','Orden Trabajo - Nuevo'),(49,'OrdenTrabajo','Edit','Orden Trabajo - Editar'),(50,'OrdenTrabajo','Delete','Orden Trabajo - Borrar'),(51,'OrdenTrabajoContactologia','Index','Orden Trabajo Contactologia - Listar'),(52,'OrdenTrabajoContactologia','Show','Orden Trabajo Contactologia - Mostrar'),(53,'OrdenTrabajoContactologia','New','Orden Trabajo Contactologia - Nuevo'),(54,'OrdenTrabajoContactologia','Edit','Orden Trabajo Contactologia - Editar'),(55,'OrdenTrabajoContactologia','Delete','Orden Trabajo Contactologia - Borrar'),(56,'Dashboard','Index','Dashboard - Listar'),(57,'ComprobanteVenta','Index','Comprobante Venta - Listar'),(58,'ComprobanteVenta','Show','Comprobante Venta - Mostrar'),(59,'ComprobanteVenta','New','Comprobante Venta - Nuevo'),(60,'ComprobanteVenta','Edit','Comprobante Venta - Editar'),(61,'ComprobanteVenta','Delete','Comprobante Venta - Borrar'),(62,'ComprobanteDetalle','Index','Comprobante Detalle - Listar'),(63,'ComprobanteDetalle','Show','Comprobante Detalle - Mostrar'),(64,'ComprobanteDetalle','New','Comprobante Detalle - Nuevo'),(65,'ComprobanteDetalle','Edit','Comprobante Detalle - Editar'),(66,'ComprobanteDetalle','Delete','Comprobante Detalle - Borrar'),(67,'ComprobanteCompra','Index','Comprobante Compra - Listar'),(68,'ComprobanteCompra','Show','Comprobante Compra - Mostrar'),(69,'ComprobanteCompra','New','Comprobante Compra - Nuevo'),(70,'ComprobanteCompra','Edit','Comprobante Compra - Editar'),(71,'ComprobanteCompra','Delete','Comprobante Compra - Borrar'),(72,'Articulo','Index','Articulo - Listar'),(73,'Articulo','Show','Articulo - Mostrar'),(74,'Articulo','New','Articulo - Nuevo'),(75,'Articulo','Edit','Articulo - Editar'),(76,'Articulo','Delete','Articulo - Borrar'),(77,'OrdenTrabajo','Cerrar','Orden Trabajo - Cerrar'),(78,'ComprobanteVenta','FacturaImprimir','Comprobante Venta - Imprimir'),(79,'ComprobanteVenta','Facturar','Comprobante Venta - Facturar'),(80,'OrdenTrabajo','OrdenImprimir','OrdenTrabajo - Imprimir'),(81,'OrdenTrabajoContactologia','OrdenImprimir','OrdenTrabajoContactologia - Imprimir'),(82,'ComprobanteCompra','PrecioVenta','ComprobanteCompra - Precio Venta');

/*Table structure for table `localidad` */

CREATE TABLE `localidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4F68E0104E7121AF` (`provincia_id`),
  KEY `IDX_4F68E010DE12AB56` (`created_by`),
  KEY `IDX_4F68E01016FE72E1` (`updated_by`),
  CONSTRAINT `FK_4F68E01016FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_4F68E0104E7121AF` FOREIGN KEY (`provincia_id`) REFERENCES `provincia` (`id`),
  CONSTRAINT `FK_4F68E010DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `localidad` */

insert  into `localidad`(`id`,`provincia_id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,1,'San Lorenzo',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(2,1,'Rosario',1,1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00'),(3,1,'Puerto Gral. San Martin',1,1,'2019-04-29 11:48:58',1,'2019-04-29 11:48:58'),(4,1,'Capitán Bermudez',1,1,'2019-04-29 11:49:19',1,'2019-04-29 11:49:19');

/*Table structure for table `medico` */

CREATE TABLE `medico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documento_tipo_id` int(11) DEFAULT NULL,
  `localidad_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `documento_numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matricula` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_34E5914C2DCBF3BC` (`documento_numero`),
  UNIQUE KEY `UNIQ_34E5914C15DF1885` (`matricula`),
  KEY `IDX_34E5914C7C9FBE9A` (`documento_tipo_id`),
  KEY `IDX_34E5914C67707C89` (`localidad_id`),
  KEY `IDX_34E5914CDE12AB56` (`created_by`),
  KEY `IDX_34E5914C16FE72E1` (`updated_by`),
  CONSTRAINT `FK_34E5914C16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_34E5914C67707C89` FOREIGN KEY (`localidad_id`) REFERENCES `localidad` (`id`),
  CONSTRAINT `FK_34E5914C7C9FBE9A` FOREIGN KEY (`documento_tipo_id`) REFERENCES `afip_documento_tipo` (`id`),
  CONSTRAINT `FK_34E5914CDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `medico` */

/*Table structure for table `obra_social` */

CREATE TABLE `obra_social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AA939553DE12AB56` (`created_by`),
  KEY `IDX_AA93955316FE72E1` (`updated_by`),
  CONSTRAINT `FK_AA93955316FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_AA939553DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `obra_social` */

insert  into `obra_social`(`id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Particular',1,1,'2019-03-08 17:14:12',1,'2019-03-08 17:14:12'),(2,'IAPOS',1,1,'2019-03-08 17:14:23',1,'2019-03-08 17:14:23'),(3,'Swiss Medical',1,1,'2019-03-08 18:09:33',1,'2019-03-08 18:09:33'),(4,'ACA Salud',1,1,'2019-06-12 11:33:31',1,'2019-06-12 11:33:31'),(5,'Sancor Salud',1,1,'2019-06-12 11:33:43',1,'2019-06-12 11:33:43'),(6,'OSDE',1,1,'2019-06-12 11:33:56',1,'2019-06-12 11:33:56'),(7,'Medife',1,1,'2019-06-12 11:34:08',1,'2019-06-12 11:34:08'),(8,'Federada Salud',1,1,'2019-06-12 11:34:41',1,'2019-06-12 11:34:41'),(9,'Otra',1,1,'2019-06-12 11:35:00',1,'2019-06-12 11:35:00');

/*Table structure for table `obra_social_plan` */

CREATE TABLE `obra_social_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `obra_social_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DEEFDD216D8BE9D2` (`obra_social_id`),
  KEY `IDX_DEEFDD21DE12AB56` (`created_by`),
  KEY `IDX_DEEFDD2116FE72E1` (`updated_by`),
  CONSTRAINT `FK_DEEFDD2116FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_DEEFDD216D8BE9D2` FOREIGN KEY (`obra_social_id`) REFERENCES `obra_social` (`id`),
  CONSTRAINT `FK_DEEFDD21DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `obra_social_plan` */

insert  into `obra_social_plan`(`id`,`obra_social_id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,1,'Particular',1,1,'2019-03-08 17:49:35',1,'2019-03-08 17:49:35'),(2,2,'Basico',1,1,'2019-03-08 17:50:29',1,'2019-03-08 17:50:29'),(4,2,'Complementario',1,1,'2019-03-08 17:50:57',1,'2019-03-08 17:50:57'),(5,3,'SM01',1,1,'2019-03-08 17:51:07',1,'2019-03-08 17:51:07'),(6,3,'SM02',1,1,'2019-03-08 17:51:17',1,'2019-03-08 17:51:17'),(7,3,'SM03',1,1,'2019-03-08 18:10:19',1,'2019-03-08 18:10:19'),(8,4,'S/E',1,1,'0000-00-00 00:00:00',1,'0000-00-00 00:00:00'),(9,5,'S/E',1,1,'2019-06-12 11:35:33',1,'0000-00-00 00:00:00'),(10,6,'S/E',1,1,'2019-06-12 11:35:44',1,'2019-06-12 11:35:44'),(11,7,'S/E',1,1,'2019-06-12 11:35:55',1,'2019-06-12 11:35:55'),(12,8,'S/E',1,1,'0000-00-00 00:00:00',1,'0000-00-00 00:00:00'),(13,9,'S/E',1,1,'2019-06-12 11:36:24',1,'0000-00-00 00:00:00');

/*Table structure for table `orden_pago` */

CREATE TABLE `orden_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `numero` int(11) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `disponible` decimal(16,2) NOT NULL,
  `saldo` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CD3AA7C9279A5D5E` (`sucursal_id`),
  KEY `IDX_CD3AA7C9CB305D73` (`proveedor_id`),
  KEY `IDX_CD3AA7C9DE12AB56` (`created_by`),
  KEY `IDX_CD3AA7C916FE72E1` (`updated_by`),
  CONSTRAINT `FK_CD3AA7C916FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_CD3AA7C9279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_CD3AA7C9CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `FK_CD3AA7C9DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_pago` */

/*Table structure for table `orden_pago_comprobante` */

CREATE TABLE `orden_pago_comprobante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_pago_id` int(11) DEFAULT NULL,
  `comprobante_id` int(11) DEFAULT NULL,
  `importe` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2871E7D8DF759BAE` (`orden_pago_id`),
  KEY `IDX_2871E7D825662B3A` (`comprobante_id`),
  KEY `IDX_2871E7D8DE12AB56` (`created_by`),
  KEY `IDX_2871E7D816FE72E1` (`updated_by`),
  CONSTRAINT `FK_2871E7D816FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_2871E7D825662B3A` FOREIGN KEY (`comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_2871E7D8DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_2871E7D8DF759BAE` FOREIGN KEY (`orden_pago_id`) REFERENCES `orden_pago` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_pago_comprobante` */

/*Table structure for table `orden_trabajo` */

CREATE TABLE `orden_trabajo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `comprobante_id` int(11) DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otros_trabajos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `taller_id` int(11) DEFAULT NULL,
  `fecha_recepcion` datetime DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `fecha_receta` datetime DEFAULT NULL,
  `fecha_taller_pedido` datetime DEFAULT NULL,
  `fecha_talle_entrega` datetime DEFAULT NULL,
  `armado` tinyint(1) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `total_bonificacion` decimal(16,2) NOT NULL,
  `entrega` decimal(16,2) NOT NULL,
  `saldo` decimal(16,2) NOT NULL,
  `lejos_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `lejos_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `lejos_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `ojo_derecho_dnp` decimal(16,2) NOT NULL,
  `ojo_izquierdo_dnp` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `antes_ojo_derecho_dnp` decimal(16,2) NOT NULL,
  `antes_ojo_izquierdo_dnp` decimal(16,2) NOT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `medico_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4158A024DE734E51` (`cliente_id`),
  KEY `IDX_4158A02425662B3A` (`comprobante_id`),
  KEY `IDX_4158A0246DC343EA` (`taller_id`),
  KEY `IDX_4158A024279A5D5E` (`sucursal_id`),
  KEY `IDX_4158A024A7FB1C0C` (`medico_id`),
  KEY `IDX_4158A024DE12AB56` (`created_by`),
  KEY `IDX_4158A02416FE72E1` (`updated_by`),
  CONSTRAINT `FK_4158A02416FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_4158A02425662B3A` FOREIGN KEY (`comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_4158A024279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_4158A0246DC343EA` FOREIGN KEY (`taller_id`) REFERENCES `taller` (`id`),
  CONSTRAINT `FK_4158A024A7FB1C0C` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`id`),
  CONSTRAINT `FK_4158A024DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_4158A024DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_trabajo` */

/*Table structure for table `orden_trabajo_contactologia` */

CREATE TABLE `orden_trabajo_contactologia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `comprobante_id` int(11) DEFAULT NULL,
  `fecha_recepcion` datetime DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `fecha_receta` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diagnostico` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motivacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uso_lc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` decimal(16,2) NOT NULL,
  `total_bonificacion` decimal(16,2) NOT NULL,
  `entrega` decimal(16,2) NOT NULL,
  `saldo` decimal(16,2) NOT NULL,
  `rc_ojo_derecho_horizontal` decimal(16,2) NOT NULL,
  `rc_ojo_izquierdo_horizontal` decimal(16,2) NOT NULL,
  `rc_ojo_derecho_vertical` decimal(16,2) NOT NULL,
  `rc_ojo_izquierdo_vertical` decimal(16,2) NOT NULL,
  `ojo_derecho_curvas` decimal(16,2) NOT NULL,
  `ojo_izquierdo_curvas` decimal(16,2) NOT NULL,
  `ojo_derecho_diametro` decimal(16,2) NOT NULL,
  `ojo_izquierdo_diametro` decimal(16,2) NOT NULL,
  `ojo_derecho_av` decimal(16,2) NOT NULL,
  `ojo_izquierdo_av` decimal(16,2) NOT NULL,
  `ojo_derecho_caracteristicas` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ojo_izquierdo_caracteristicas` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lejos_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `lejos_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `lejos_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `lejos_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `cerca_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `cerca_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `ojo_derecho_dnp` decimal(16,2) NOT NULL,
  `ojo_izquierdo_dnp` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `antes_lejos_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_eje` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_eje` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_cilindro` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_cilindro` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_derecho_esfera` decimal(16,2) NOT NULL,
  `antes_cerca_ojo_izquierdo_esfera` decimal(16,2) NOT NULL,
  `antes_ojo_derecho_dnp` decimal(16,2) NOT NULL,
  `antes_ojo_izquierdo_dnp` decimal(16,2) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `medico_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_56DAF2F1DE734E51` (`cliente_id`),
  KEY `IDX_56DAF2F125662B3A` (`comprobante_id`),
  KEY `IDX_56DAF2F1279A5D5E` (`sucursal_id`),
  KEY `IDX_56DAF2F1A7FB1C0C` (`medico_id`),
  KEY `IDX_56DAF2F1DE12AB56` (`created_by`),
  KEY `IDX_56DAF2F116FE72E1` (`updated_by`),
  CONSTRAINT `FK_56DAF2F116FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_56DAF2F125662B3A` FOREIGN KEY (`comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_56DAF2F1279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_56DAF2F1A7FB1C0C` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`id`),
  CONSTRAINT `FK_56DAF2F1DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_56DAF2F1DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_trabajo_contactologia` */

/*Table structure for table `orden_trabajo_contactologia_detalle` */

CREATE TABLE `orden_trabajo_contactologia_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_trabajo_contactologia_id` int(11) DEFAULT NULL,
  `articulo_id` int(11) DEFAULT NULL,
  `importe_bonificacion` decimal(16,2) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `precio_venta` decimal(16,2) NOT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `tipo_cristal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje_bonificacion` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_30A7A74B92CB6474` (`orden_trabajo_contactologia_id`),
  KEY `IDX_30A7A74B2DBC2FC9` (`articulo_id`),
  KEY `IDX_30A7A74BDE12AB56` (`created_by`),
  KEY `IDX_30A7A74B16FE72E1` (`updated_by`),
  CONSTRAINT `FK_30A7A74B16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_30A7A74B2DBC2FC9` FOREIGN KEY (`articulo_id`) REFERENCES `articulo` (`id`),
  CONSTRAINT `FK_30A7A74B92CB6474` FOREIGN KEY (`orden_trabajo_contactologia_id`) REFERENCES `orden_trabajo_contactologia` (`id`),
  CONSTRAINT `FK_30A7A74BDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_trabajo_contactologia_detalle` */

/*Table structure for table `orden_trabajo_detalle` */

CREATE TABLE `orden_trabajo_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_trabajo_id` int(11) DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `estado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `articulo_id` int(11) DEFAULT NULL,
  `importe_bonificacion` decimal(16,2) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `precio_venta` decimal(16,2) NOT NULL,
  `tipo_cristal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje_bonificacion` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4BA8D9EC92B24E62` (`orden_trabajo_id`),
  KEY `IDX_4BA8D9EC2DBC2FC9` (`articulo_id`),
  KEY `IDX_4BA8D9ECDE12AB56` (`created_by`),
  KEY `IDX_4BA8D9EC16FE72E1` (`updated_by`),
  CONSTRAINT `FK_4BA8D9EC16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_4BA8D9EC2DBC2FC9` FOREIGN KEY (`articulo_id`) REFERENCES `articulo` (`id`),
  CONSTRAINT `FK_4BA8D9EC92B24E62` FOREIGN KEY (`orden_trabajo_id`) REFERENCES `orden_trabajo` (`id`),
  CONSTRAINT `FK_4BA8D9ECDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `orden_trabajo_detalle` */

/*Table structure for table `pago_tipo` */

CREATE TABLE `pago_tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_567222FBDE12AB56` (`created_by`),
  KEY `IDX_567222FB16FE72E1` (`updated_by`),
  CONSTRAINT `FK_567222FB16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_567222FBDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `pago_tipo` */

insert  into `pago_tipo`(`id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Efectivo',1,1,'2019-04-03 19:42:26',1,'2019-04-03 19:42:26'),(2,'Tarjeta de Debito',1,1,'2019-04-03 19:42:59',1,'2019-04-03 19:42:59'),(3,'Tarjeta de Credito',1,1,'2019-04-03 19:43:03',1,'2019-04-03 19:43:03'),(4,'Cheque',1,1,'2019-04-03 19:43:14',1,'2019-04-03 19:43:14'),(5,'Transferencia',1,1,'2019-04-03 19:43:18',1,'2019-04-03 19:43:18'),(6,'Otro',1,1,'2019-04-03 19:43:24',1,'2019-04-03 19:43:24');

/*Table structure for table `proveedor` */

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `documento_numero` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `localidad_id` int(11) DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `iva_condicion_id` int(11) DEFAULT NULL,
  `documento_tipo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_16C068CE2DCBF3BC` (`documento_numero`),
  KEY `IDX_16C068CE67707C89` (`localidad_id`),
  KEY `IDX_16C068CE42D4BDD0` (`iva_condicion_id`),
  KEY `IDX_16C068CE7C9FBE9A` (`documento_tipo_id`),
  KEY `IDX_16C068CEDE12AB56` (`created_by`),
  KEY `IDX_16C068CE16FE72E1` (`updated_by`),
  CONSTRAINT `FK_16C068CE16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_16C068CE42D4BDD0` FOREIGN KEY (`iva_condicion_id`) REFERENCES `afip_iva_condicion` (`id`),
  CONSTRAINT `FK_16C068CE67707C89` FOREIGN KEY (`localidad_id`) REFERENCES `localidad` (`id`),
  CONSTRAINT `FK_16C068CE7C9FBE9A` FOREIGN KEY (`documento_tipo_id`) REFERENCES `afip_documento_tipo` (`id`),
  CONSTRAINT `FK_16C068CEDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `proveedor` */

/*Table structure for table `proveedor_pago` */

CREATE TABLE `proveedor_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_pago_id` int(11) DEFAULT NULL,
  `pago_tipo_id` int(11) DEFAULT NULL,
  `importe` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8C7A85E4DF759BAE` (`orden_pago_id`),
  KEY `IDX_8C7A85E4C6690F67` (`pago_tipo_id`),
  KEY `IDX_8C7A85E4DE12AB56` (`created_by`),
  KEY `IDX_8C7A85E416FE72E1` (`updated_by`),
  CONSTRAINT `FK_8C7A85E416FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_8C7A85E4C6690F67` FOREIGN KEY (`pago_tipo_id`) REFERENCES `pago_tipo` (`id`),
  CONSTRAINT `FK_8C7A85E4DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_8C7A85E4DF759BAE` FOREIGN KEY (`orden_pago_id`) REFERENCES `orden_pago` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `proveedor_pago` */

/*Table structure for table `provincia` */

CREATE TABLE `provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D39AF213DE12AB56` (`created_by`),
  KEY `IDX_D39AF21316FE72E1` (`updated_by`),
  CONSTRAINT `FK_D39AF21316FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_D39AF213DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `provincia` */

insert  into `provincia`(`id`,`nombre`,`activo`,`updated_at`,`updated_by`,`created_at`,`created_by`) values (1,'Santa Fe',1,'2018-01-01 00:00:00',1,'2018-01-01 00:00:00',1),(2,'Buenos Aires',1,'2019-06-12 11:13:34',1,'2019-06-12 11:13:34',1);

/*Table structure for table `recibo` */

CREATE TABLE `recibo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `numero` int(11) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `disponible` decimal(16,2) NOT NULL,
  `saldo` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_42A928FA279A5D5E` (`sucursal_id`),
  KEY `IDX_42A928FADE734E51` (`cliente_id`),
  KEY `IDX_42A928FADE12AB56` (`created_by`),
  KEY `IDX_42A928FA16FE72E1` (`updated_by`),
  CONSTRAINT `FK_42A928FA16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_42A928FA279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_42A928FADE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_42A928FADE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `recibo` */

/*Table structure for table `recibo_comprobante` */

CREATE TABLE `recibo_comprobante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recibo_id` int(11) DEFAULT NULL,
  `comprobante_id` int(11) DEFAULT NULL,
  `importe` decimal(16,2) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3CAF3E012C458692` (`recibo_id`),
  KEY `IDX_3CAF3E0125662B3A` (`comprobante_id`),
  KEY `IDX_3CAF3E01DE12AB56` (`created_by`),
  KEY `IDX_3CAF3E0116FE72E1` (`updated_by`),
  CONSTRAINT `FK_3CAF3E0116FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_3CAF3E0125662B3A` FOREIGN KEY (`comprobante_id`) REFERENCES `comprobante` (`id`),
  CONSTRAINT `FK_3CAF3E012C458692` FOREIGN KEY (`recibo_id`) REFERENCES `recibo` (`id`),
  CONSTRAINT `FK_3CAF3E01DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `recibo_comprobante` */

/*Table structure for table `rol` */

CREATE TABLE `rol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E553F37DE12AB56` (`created_by`),
  KEY `IDX_E553F3716FE72E1` (`updated_by`),
  CONSTRAINT `FK_E553F3716FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_E553F37DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `rol` */

insert  into `rol`(`id`,`descripcion`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Administrador',1,1,'2019-05-21 19:39:17',1,'2019-05-22 22:38:36'),(2,'Gerente',1,1,'2019-05-21 19:39:17',1,'2019-05-21 19:39:17'),(3,'Vendedor',1,1,'2019-05-22 19:58:16',1,'2019-05-24 18:42:08');

/*Table structure for table `rol_funcion` */

CREATE TABLE `rol_funcion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_id` int(11) DEFAULT NULL,
  `funcion_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6805290D4BAB96C` (`rol_id`),
  KEY `IDX_6805290D8C185C36` (`funcion_id`),
  CONSTRAINT `FK_6805290D4BAB96C` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`),
  CONSTRAINT `FK_6805290D8C185C36` FOREIGN KEY (`funcion_id`) REFERENCES `funcion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `rol_funcion` */

insert  into `rol_funcion`(`id`,`rol_id`,`funcion_id`) values (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,1,15),(16,1,16),(17,1,17),(18,1,18),(19,1,19),(20,1,20),(21,1,21),(22,1,22),(23,1,23),(24,1,24),(25,1,25),(26,1,26),(27,1,27),(28,1,28),(29,1,29),(30,1,30),(31,1,31),(32,1,32),(33,1,33),(34,1,34),(35,1,35),(36,1,36),(37,1,37),(38,1,38),(39,1,39),(40,1,40),(41,1,41),(42,1,42),(43,1,43),(44,1,44),(45,1,45),(46,1,46),(47,1,47),(48,1,48),(49,1,49),(50,1,50),(51,1,51),(52,1,52),(53,1,53),(54,1,54),(55,1,55),(56,1,56),(57,1,57),(58,1,58),(59,1,59),(60,1,60),(61,1,61),(62,1,62),(63,1,63),(64,1,64),(65,1,65),(66,1,66),(67,1,67),(68,1,68),(69,1,69),(70,1,70),(71,1,71),(72,1,72),(73,1,73),(74,1,74),(75,1,75),(76,1,76),(77,1,77),(78,1,78),(79,1,79),(80,1,80),(81,1,81),(82,2,82);

/*Table structure for table `sucursal` */

CREATE TABLE `sucursal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E99C6D563A909126` (`nombre`),
  KEY `IDX_E99C6D56DE12AB56` (`created_by`),
  KEY `IDX_E99C6D5616FE72E1` (`updated_by`),
  CONSTRAINT `FK_E99C6D5616FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_E99C6D56DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `sucursal` */

insert  into `sucursal`(`id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Casa Central',1,1,'2019-03-06 17:13:01',1,'2019-03-06 17:13:01'),(2,'Entre Ríos',1,1,'2019-03-06 17:13:12',1,'2019-03-06 17:13:12'),(3,'PGSM',1,1,'2019-03-06 17:13:21',1,'2019-03-06 17:13:21'),(4,'Capitán Bermudez',1,1,'2019-06-12 11:30:17',1,'2019-06-12 11:30:17'),(5,'Palermo',1,1,'2019-06-12 11:32:29',1,'2019-06-12 11:32:29');

/*Table structure for table `taller` */

CREATE TABLE `taller` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_139F4584DE12AB56` (`created_by`),
  KEY `IDX_139F458416FE72E1` (`updated_by`),
  CONSTRAINT `FK_139F458416FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_139F4584DE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `taller` */

insert  into `taller`(`id`,`nombre`,`activo`,`created_by`,`created_at`,`updated_by`,`updated_at`) values (1,'Externo',1,1,'2019-03-06 18:30:38',1,'2019-03-06 18:30:38');

/*Table structure for table `usuario` */

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `usuario` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `login_ultimo` datetime NOT NULL,
  `login_cantidad` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `rol_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2265B05D2265B05D` (`usuario`),
  KEY `IDX_2265B05D279A5D5E` (`sucursal_id`),
  KEY `IDX_2265B05D4BAB96C` (`rol_id`),
  KEY `IDX_2265B05DDE12AB56` (`created_by`),
  KEY `IDX_2265B05D16FE72E1` (`updated_by`),
  CONSTRAINT `FK_2265B05D16FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `usuario` (`id`),
  CONSTRAINT `FK_2265B05D279A5D5E` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `FK_2265B05D4BAB96C` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`),
  CONSTRAINT `FK_2265B05DDE12AB56` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `usuario` */

insert  into `usuario`(`id`,`nombre`,`apellido`,`usuario`,`password`,`activo`,`email`,`login_ultimo`,`login_cantidad`,`created_by`,`created_at`,`updated_by`,`updated_at`,`sucursal_id`,`rol_id`) values (1,'Usuario','Administrador','admin','$2y$13$abP2NlRAHD7LcJkdFyGO.u0RdfSEI/pZ.He6mM7jpMPnhRhzuMkGi',1,'-','2018-08-30 17:04:13',0,1,'2018-08-30 17:04:13',1,'2019-06-12 12:00:01',1,1),(2,'Carlos','Arroyo','carroyo','$2y$13$E9cV9QbktbD93KDSb/sIde3n8lirQjQcDyd0tarRrchr1zZzPdlX.',1,'opticacontini@live.com.ar','2018-08-30 18:01:29',0,1,'2018-08-30 18:01:29',1,'2018-09-06 18:09:27',NULL,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
